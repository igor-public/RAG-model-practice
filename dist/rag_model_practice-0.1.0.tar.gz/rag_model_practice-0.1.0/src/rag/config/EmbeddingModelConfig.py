from dataclasses import dataclass

@dataclass
class EmbeddingModelConfig:
   embedding_model_name: str